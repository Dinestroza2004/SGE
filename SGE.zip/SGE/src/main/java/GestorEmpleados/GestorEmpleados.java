/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.GestorEmpleados to edit this template
 */
package GestorEmpleados;
import Empleado.Empleado;
import java.util.ArrayList;

/**
 * 
 *
 * @author Pc
 */
public class GestorEmpleados {
    private ArrayList<Empleado> empleados;

    public GestorEmpleados() {
        empleados = new ArrayList<>();
    }

    // Método para agregar un empleado
    public void agregarEmpleado(Empleado empleado) {
        empleados.add(empleado);
        System.out.println("Empleado agregado con éxito.");
    }

    // Método para mostrar los detalles de todos los empleados
    public void mostrarEmpleados() {
        if (empleados.isEmpty()) {
            System.out.println("No hay empleados para mostrar.");
        } else {
            for (Empleado empleado : empleados) {
                empleado.mostrarInfo();
                System.out.println("-------------------------");
            }
        }
    }
}
